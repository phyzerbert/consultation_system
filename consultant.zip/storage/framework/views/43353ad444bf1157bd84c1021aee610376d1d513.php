<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-database"></i>&nbsp;Knowledge Base</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home fa-lg"></i></a></li>
            <li class="breadcrumb-item"><a href="#">Knowledge Base</a></li>
        </ul>
    </div>
    <div class="">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="tile">
                    <div class="tile-header">                     
                        <h3>Edit Article</h3>                                 
                    </div>
                    <div class="tile-body">                        
                        <form method="post" action="<?php echo e(route('kdb.update')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <input type="hidden" name="id" value="<?php echo e($kdb->id); ?>">
                                <div class="col-md-12 mb-4">
                                    <label>Knowledge Base Number</label>
                                    <input class="form-control" type="text" name="kb_number" id="kb_number" value="<?php echo e($kdb->kb_number); ?>" readonly>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-md-12 mb-4">
                                    <label>Category</label>
                                    <select name="category" id="category" class="form-control">
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php if($kdb->category_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-md-12 mb-4">
                                    <label>Problem</label>
                                    <input class="form-control" type="text" name="problem" value="<?php echo e($kdb->problem); ?>" id="problem" placeholder="Type maximum 25 characters" />
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-md-12 mb-4">
                                    <label>Solution</label>
                                    <textarea class="form-control" name="solution" id="solution" rows="5" placeholder="Type Solution..."><?php echo e($kdb->solution); ?></textarea>
                                </div>
                            </div>
                            <div class="row mb-10">
                                <div class="col-md-12">
                                    <a href="<?php echo e(route('kdb.index')); ?>" class="btn btn-danger float-right"><i class="fa fa-fw fa-lg fa-undo"></i> Back</a>
                                    <button class="btn btn-primary float-right mr-2" id="profile-submit" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i> Save</button>
                                </div>
                            </div>
                        </form>
                    </div>                   
                </div>
            </div>            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\helpdesk\BoltonUniversity\BoltonUniversity\itsupport\resources\views/kdb/edit.blade.php */ ?>