<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-users"></i>&nbsp;Consultant Dashboard</h1>
        <!-- <p>A free and open source Bootstrap 4 admin template</p> -->
    </div>
    <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home fa-lg"></i></a></li>
        <li class="breadcrumb-item"><a href="#">Consultant Dashboard</a></li>
    </ul>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="tile">
                <div class="col-md-12">
                    <form action="" method="POST" class="form-inline">
                        <?php echo csrf_field(); ?> 
                        <label class="control-label mr-sm-2 mb-2" for="period">Type Of Issue: </label>
                        <select class="form-control form-control-sm mr-sm-3 mb-2" name="category_id" id="search_category">
                            <option value="">Select a type of issue</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($category_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label class="control-label mr-sm-2 mb-2" for="period">Consultant: </label>
                        <select class="form-control form-control-sm mr-sm-3 mb-2" name="consultant_id" id="search_consultant">
                            <option value="">Select a consultant</option>
                            <?php $__currentLoopData = $consultants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($consultant_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label class="control-label mr-sm-2 mb-2" for="period">Status: </label>
                        <select class="form-control form-control-sm mr-sm-3 mb-2" name="status" id="search_status">
                            <option value="">Select a Status</option>
                            <option value="0" <?php if($status == '0'): ?> selected <?php endif; ?>>Pending</option>
                            <option value="1" <?php if($status == '1'): ?> selected <?php endif; ?>>Answered</option>
                            <option value="2" <?php if($status == '2'): ?> selected <?php endif; ?>>Closed</option>                            
                        </select>
                        <label class="control-label mr-sm-2 mb-2" for="period">Requested Time: </label>
                        <input type="text" class="form-control form-control-sm col-md-2 mr-sm-2 mb-2" name="period" id="period" autocomplete="off" value="<?php echo e($period); ?>">
                        <button type="submit" class="btn btn-sm btn-primary mb-2"><i class="fa fa-search"></i>&nbsp;Search</button>
                        <button type="button" class="btn btn-sm btn-info mb-2 ml-3" id="btn-reset"><i class="fa fa-eraser"></i>&nbsp;Reset</button>
                    </form>
                </div>
                <div class="tile-body mt-3">
                    <table class="table table-hover table-bordered text-center">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>UserID</th>
                                <th>Type of Issue</th>
                                <th>Subject</th>
                                <th>Consultant</th>
                                <th>Status</th>
                                <th>Requested Time</th>
                                <th>Action</th>
                            </tr>
                        </thead>    
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <input type="hidden" class="description" value="<?php echo e($item->description); ?>">
                                <input type="hidden" class="answer" value="<?php echo e($item->answer); ?>">
                                <input type="hidden" class="attachment" data-value="<?php echo e(basename($item->file_path)); ?>" value="<?php echo e($item->file_path); ?>">
                                <td><?php echo e(($page_number-1) * 10 + $loop->index+1); ?></td>
                                <td class="user_id"><?php echo e($item->user->name); ?></td>
                                <td class="category"><?php echo e($item->category->name); ?></td>
                                <td class="subject"><?php echo e($item->subject); ?></td>
                                <td class="consultant"><?php if(isset($item->consultant->name)): ?> <?php echo e($item->consultant->name); ?> <?php endif; ?></td>
                                <td class="status">
                                    <?php if($item->status == 2): ?>
                                        Closed
                                    <?php elseif($item->status == 1): ?>
                                        Answered
                                    <?php else: ?>
                                        Pending
                                    <?php endif; ?>
                                </td>
                                <td class="timestamp"><?php echo e($item->created_at); ?></td>
                                <td class="action py-2">
                                    <a href="#" class="btn btn-info btn-sm btn-view" data-id="<?php echo e($item->id); ?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="View"><i class="fa fa-info-circle" style="font-size:20px"></i>View</a>
                                    <?php if($item->status == 0): ?>
                                        <a href="#" class="btn btn-primary btn-sm btn-reply" data-id="<?php echo e($item->id); ?>" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Reply"><i class="fa fa-reply" style="font-size:20px"></i>Reply</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="clearfix">
                        <div class="pull-left" style="margin: 0;">
                            <p>Total <strong style="color: red"><?php echo e($data->total()); ?></strong> Items</p>
                        </div>
                        <div class="pull-right" style="margin: 0;">
                            <?php echo $data->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="viewModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Question Detail</h4>
                <button type="button" class="close" data-dismiss="modal">×</button>
            </div>
                <div class="modal-body p-5">
                    <div class="row mb-2">
                        <label class="col-sm-3 text-right">Subject :</label>
                        <label class="col-sm-9 subject"></label>
                    </div>
                    <div class="row mb-2">
                        <label class="col-sm-3 text-right">Type Of Issue :</label>
                        <label class="col-sm-9 category"></label>
                    </div>
                    <div class="row mb-2">
                        <label class="col-sm-3 text-right">Description :</label>
                        <pre class="col-sm-9 description"></pre>
                    </div>
                    
                    <div class="row mb-2">
                        <label class="col-sm-3 text-right">Attachment :</label>
                        <div class="col-sm-9 attachment"><a href="" download></a></div>
                    </div>
                    <div class="row mb-2">
                        <label class="col-sm-3 text-right">Status :</label>
                        <label class="col-sm-9 status"></label>
                    </div>
                    <div class="row mb-2">
                        <label class="col-sm-3 text-right">Consultant :</label>
                        <label class="col-sm-9 consultant"></label>
                    </div>                    
                    <div class="row mb-2">
                        <label class="col-sm-3 text-right">Answer :</label>
                        <pre class="col-sm-9 answer"></pre>
                    </div>
                </div>
                <div class="modal-footer">
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="replyModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Reply to Question</h4>
                <button type="button" class="close" data-dismiss="modal">×</button>
            </div>
            <form action="<?php echo e(route('question.reply')); ?>" id="create_form" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <input type="hidden" class="id" name="id" />
                    <input type="hidden" class="consultant" name="consultant_id" value="<?php echo e(Auth::user()->id); ?>" />
                    <div class="form-group">
                        <label class="control-label">Subject:</label>
                        <p class="subject field"></p>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Type Of Issue:</label>
                        <p class="category field"></p>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description:</label>
                        <pre class="description field"></pre>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Answer:</label>
                        <textarea class="form-control" name="answer" id="answer" rows="4" required placeholder="Answer"></textarea>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" id="btn_create" class="btn btn-primary btn-submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>&nbsp;Save</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-fw fa-lg fa-times-circle"></i>&nbsp;Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>
    $(document).ready(function () {
        var public_path = "<?php echo e(asset('')); ?>";
        $(".btn-view").click(function(){
            let id = $(this).data('id');
            let category = $(this).parents('tr').find(".category").text();
            let subject = $(this).parents('tr').find(".subject").text();
            let consultant = $(this).parents('tr').find(".consultant").text();
            let status = $(this).parents('tr').find(".status").text();
            let description = $(this).parents('tr').find(".description").val().trim();
            let answer = $(this).parents('tr').find(".answer").val().trim();
            let attachment = $(this).parents('tr').find(".attachment").val().trim();
            let filename = $(this).parents('tr').find(".attachment").data('value');
            $("#viewModal .field").text('');
            $("#viewModal .category").text(category);
            $("#viewModal .subject").text(subject);
            $("#viewModal .consultant").text(consultant);
            $("#viewModal .status").text(status);
            $("#viewModal .description").text(description);
            $("#viewModal .answer").text(answer);
            $("#viewModal .attachment a").attr("href", public_path + attachment);
            $("#viewModal .attachment a").text(filename);            
            $("#viewModal").modal();
        });

        $(".btn-reply").click(function(){
            let id = $(this).data('id');
            let category = $(this).parents('tr').find(".category").text();
            let subject = $(this).parents('tr').find(".subject").text();
            let description = $(this).parents('tr').find(".description").val().trim();
            $("#replyModal .field").text('');
            $("#replyModal .id").val(id);
            $("#replyModal .category").text(category);
            $("#replyModal .subject").text(subject); 
            $("#replyModal .description").text(description);      
            $("#replyModal").modal();
        })

        
        $("#btn-reset").click(function(){
            $("#search_category").val('');
            $("#search_consultant").val('');
            $("#search_status").val('');
            $("#period").val('');
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\Consultant\consultant\resources\views/consultant/dashboard.blade.php */ ?>