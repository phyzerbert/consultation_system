<?php echo e($slot); ?>


<?php /* E:\Consultant\consultant\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php */ ?>