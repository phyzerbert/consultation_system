<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-folder-open"></i>&nbsp;Search an Incident(s)</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="#">Search an Incident(s)</a></li>
        </ul>
    </div>
    <div class="">
        <div class="row">
            <div class="col-md-12 mx-auto">
                <div class="tile">
                    <div class="tile-header">                     
                        <h3 class="tile-title">Search an Incident(s)</h3>                    
                        <form class="form-inline" action="<?php echo e(route("incident.search")); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <label class="control-label">User ID</label>
                            <input class="form-control form-control-sm ml-3" type="text" name="username" value="<?php echo e($username); ?>" placeholder="User ID">
                            <label class="control-label ml-3">First Name</label>
                            <input class="form-control form-control-sm ml-3" type="text" name="firstname" value="<?php echo e($firstname); ?>" placeholder="First Name">
                            <label class="control-label ml-3">Last Name</label>
                            <input class="form-control form-control-sm ml-3" type="text" name="lastname" value="<?php echo e($lastname); ?>" placeholder="Last Name">                        
                            <label class="control-label ml-3">Phone Number</label>
                            <input class="form-control form-control-sm ml-2" type="text" name="phone" value="<?php echo e($phone); ?>" placeholder="Phone Number">
                            <label class="control-label ml-3">Urgency</label>
                            <label class="form-check-label ml-3">
                                <input class="form-check-input" type="radio" name="urgency" value="0" <?php if($urgency != "1"): ?> checked <?php endif; ?>>Low
                            </label>
                            <label class="form-check-label ml-3">
                                <input class="form-check-input" type="radio" name="urgency" value="1" <?php if($urgency == "1"): ?> checked <?php endif; ?>>High
                            </label>
                            <button class="btn btn-primary btn-sm ml-4" type="submit"><i class="fa fa-fw fa-lg fa-search"></i>Search Now</button>
                            
                        </form>                       
                    </div>
                    <div class="tile-body mt-3">
                        <?php echo csrf_field(); ?>
                        <table class="table table-hover table-bordered text-center" id="documentTable">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>User ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Phone Number</th>
                                    <th>Urgency</th>
                                    <th>Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(($page_number-1) * 10 + $loop->index+1); ?></td>
                                        <td class="username"><?php if(isset($item->user)): ?> <?php echo e($item->user->name); ?> <?php endif; ?></td>
                                        <td class="firstname"><?php if(isset($item->user)): ?> <?php echo e($item->user->firstname); ?> <?php endif; ?></td>
                                        <td class="lastname"><?php if(isset($item->user)): ?> <?php echo e($item->user->lastname); ?> <?php endif; ?></td>
                                        <td class="phone"><?php if(isset($item->user)): ?> <?php echo e($item->user->phone); ?> <?php endif; ?></td>
                                        <td class="urgency"><?php if($item->urgency == "0"): ?> Low <?php else: ?> High <?php endif; ?></td>
                                        <td class=""><?php echo e($item->description); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                            </tbody>
                        </table>
                        <div class="clearfix">
                            <div class="pull-left" style="margin: 0;">
                                <p>Total <strong style="color: red"><?php echo e($incidents->total()); ?></strong> Incidents</p>
                            </div>
                            <div class="pull-right" style="margin: 0;">
                                <?php echo $incidents->links(); ?>

                            </div>
                        </div>
                    </div>                   
                </div>
            </div>            
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\helpdesk\helpdesk\resources\views/search.blade.php */ ?>