<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-database"></i>&nbsp;Knowledge Database</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="#">Knowledge Database</a></li>
        </ul>
    </div>
    <div class="">
        <div class="row">
            <div class="col-md-12 mx-auto">
                <div class="tile">
                    <div class="tile-header">                     
                        <h3 class="tile-title float-left">Knowledge Database</h3>
                        <div class="float-right">
                            <form class="form-inline" action="<?php echo e(route("kdb.index")); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input class="form-control ml-3" type="text" name="key" value="<?php echo e($key); ?>" placeholder="Search">                            
                                <button class="btn btn-primary ml-4" type="submit"><i class="fa fa-fw fa-lg fa-search"></i>Search Now</button>                            
                            </form>  
                        </div>                                             
                    </div>
                    <div class="tile-body mt-3">
                        <?php echo csrf_field(); ?>
                        <table class="table table-hover table-bordered text-center" id="documentTable">
                            <thead>
                                <tr>
                                    <th width="30">No</th>
                                    <th>Problem</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $problems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(($page_number-1) * 10 + $loop->index+1); ?></td>
                                        <td class="problem"><a href="<?php echo e(route('kdb.solution', $item->id)); ?>"><?php if(isset($item->problem)): ?> <?php echo e($item->problem); ?> <?php endif; ?></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                            </tbody>
                        </table>
                        <div class="clearfix">
                            <div class="pull-left" style="margin: 0;">
                                <p>Total <strong style="color: red"><?php echo e($problems->total()); ?></strong> Problems</p>
                            </div>
                            <div class="pull-right" style="margin: 0;">
                                <?php echo $problems->links(); ?>

                            </div>
                        </div>
                    </div>                   
                </div>
            </div>            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\helpdesk\helpdesk\resources\views/kdb.blade.php */ ?>