<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-folder-open"></i>&nbsp;Get a Consultant</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home fa-lg"></i></a></li>
            <li class="breadcrumb-item"><a href="#">Get a Consultant</a></li>
        </ul>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="tile">
                    <h3 class="tile-title">Get a Consultant</h3>                    
                    <form action="<?php echo e(route("question.create")); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                        <div class="tile-body">
                            <div class="form-group">
                                <label class="control-label">Type of Issue</label>
                                <select name="category_id" id="category_id" class="form-control">
                                    <option value="">Select a type of issue</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Subject</label>
                                <input class="form-control" type="text" name="subject" id="subject" placeholder="Subject">
                            </div>
                            <div class="form-group">
                                <label class="control-label">Query Description</label>
                                <textarea class="form-control" name="description" rows="4" id="description" placeholder="Description"></textarea>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Attachment</label>
                                <input class="form-control" type="file" name="file_path">
                            </div>
                        </div>
                        <div class="tile-footer" style="height: 60px;">
                            <div class="float-right">
                                <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Save</button>
                                <a class="btn btn-secondary" id="btn-reset" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Reset</a>
                            </div>                            
                        </div>
                    </form>
                </div>
            </div>            
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(function(){
        $("#btn-reset").click(function(){
            $("#category_id").val('');
            $("#subject").val('');
            $("#description").val('');
            $("#file_path").val('');
        });
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\Consultant\consultant\resources\views/user/dashboard.blade.php */ ?>